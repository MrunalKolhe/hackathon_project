let enrollBtn = document.querySelector('.btn');

enrollBtn.addEventListener('click', function(){
    alert("Registration Successful!!! 🎉");
});
